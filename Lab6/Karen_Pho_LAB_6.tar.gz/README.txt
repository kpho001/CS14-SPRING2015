Karen Pho
SID: 861103904
Date: May 13, 2015

Question 2:
a.  My selection sort is stable because it works with regular vectors and vectors
    of pairs. Basically it can work with most containers. Then I tried to switch
    the order of input into the vector and the swap works for it as well.
    
b.  The tests are in main.